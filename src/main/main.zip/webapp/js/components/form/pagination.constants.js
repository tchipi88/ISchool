(function() {
    'use strict';

    angular
        .module('app')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
