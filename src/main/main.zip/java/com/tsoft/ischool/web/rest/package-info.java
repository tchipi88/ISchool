/**
 * Spring MVC REST controllers.
 */
package com.itsolution.tkbr.web.rest;
