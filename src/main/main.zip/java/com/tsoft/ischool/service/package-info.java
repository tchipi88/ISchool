/**
 * Service layer beans.
 */
package com.tsoft.ischool.service;
