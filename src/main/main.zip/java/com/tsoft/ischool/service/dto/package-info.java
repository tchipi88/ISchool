/**
 * Data Transfer Objects.
 */
package com.tsoft.ischool.service.dto;
