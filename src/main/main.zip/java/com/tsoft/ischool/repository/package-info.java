/**
 * Spring Data JPA repositories.
 */
package com.tsoft.ischool.repository;
