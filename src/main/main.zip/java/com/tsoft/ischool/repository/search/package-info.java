/**
 * Spring Data Elasticsearch repositories.
 */
package com.tsoft.ischool.repository.search;
