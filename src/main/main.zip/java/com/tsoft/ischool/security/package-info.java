/**
 * Spring Security configuration.
 */
package com.tsoft.ischool.security;
