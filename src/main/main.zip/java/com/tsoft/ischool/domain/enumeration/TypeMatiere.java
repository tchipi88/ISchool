/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tsoft.ischool.domain.enumeration;



/**
 *
 * @author tchipi
 */

public enum TypeMatiere  {

   MATIERES_SCIENTIFIQUES,MATIERES_LITTERAIRES,MATIERES_FORMATIONS_HUMAINES;
}
